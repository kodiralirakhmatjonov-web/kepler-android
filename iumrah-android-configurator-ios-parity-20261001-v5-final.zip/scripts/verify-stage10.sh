#!/usr/bin/env bash
set -euo pipefail
bash scripts/verify-stage9.sh
required=(
  app/src/main/java/com/iumrah/beta/ui/generator/GeneratorChrome.kt
  app/src/main/java/com/iumrah/beta/ui/trip/TripBuilderScreen.kt
  app/src/main/java/com/iumrah/beta/ui/trip/HotelSelectionScreen.kt
  app/src/main/java/com/iumrah/beta/ui/flights/FlightSearchScreen.kt
  app/src/main/java/com/iumrah/beta/ui/packageflow/TransferSelectionScreen.kt
  app/src/main/java/com/iumrah/beta/ui/packageflow/FinalPackageScreen.kt
  app/src/main/java/com/iumrah/beta/ui/booking/BookingCheckoutScreen.kt
  app/src/main/java/com/iumrah/beta/domain/trip/TransferModels.kt
)
for f in "${required[@]}"; do test -s "$f" || { echo "STOP: missing Configurator parity file $f"; exit 1; }; done
grep -q 'data object ReturnFlights' app/src/main/java/com/iumrah/beta/core/navigation/AppChromeStore.kt
grep -q 'data object TransferSelection' app/src/main/java/com/iumrah/beta/core/navigation/AppChromeStore.kt
grep -q 'GeneratorStage.TRIP' app/src/main/java/com/iumrah/beta/ui/trip/TripBuilderScreen.kt
grep -q 'GeneratorStage.HOTEL' app/src/main/java/com/iumrah/beta/ui/trip/HotelSelectionScreen.kt
grep -q 'GeneratorStage.FLIGHT' app/src/main/java/com/iumrah/beta/ui/flights/FlightSearchScreen.kt
grep -q 'GeneratorStage.TRANSFER' app/src/main/java/com/iumrah/beta/ui/packageflow/TransferSelectionScreen.kt
grep -q 'GeneratorStage.READY' app/src/main/java/com/iumrah/beta/ui/packageflow/FinalPackageScreen.kt
grep -q 'TransferVehicleKind.CARNIVAL' app/src/main/java/com/iumrah/beta/ui/packageflow/TransferSelectionScreen.kt
grep -q 'HaramainFareClass' app/src/main/java/com/iumrah/beta/ui/packageflow/TransferSelectionScreen.kt
grep -q 'packageEngine.packageQuote(state)' app/src/main/java/com/iumrah/beta/domain/pricing/PackageGenerator.kt
if grep -R -nE 'material\.icons|Icons\.' \
  app/src/main/java/com/iumrah/beta/ui/generator \
  app/src/main/java/com/iumrah/beta/ui/trip/TripBuilderScreen.kt \
  app/src/main/java/com/iumrah/beta/ui/trip/HotelSelectionScreen.kt \
  app/src/main/java/com/iumrah/beta/ui/flights/FlightSearchScreen.kt \
  app/src/main/java/com/iumrah/beta/ui/packageflow/TransferSelectionScreen.kt \
  app/src/main/java/com/iumrah/beta/ui/booking/BookingCheckoutScreen.kt; then
  echo 'STOP: Configurator flow must use Cupertino renderer, not Material icons'; exit 1
fi
echo 'Stage 010 iOS Configurator parity checks passed.'
