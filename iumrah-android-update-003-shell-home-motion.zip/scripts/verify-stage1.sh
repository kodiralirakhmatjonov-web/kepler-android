#!/usr/bin/env bash
set -euo pipefail

test -f ANDROID_BOOTSTRAP_001_APPLIED.txt
test -f app/build.gradle.kts
test -f app/src/main/java/com/iumrah/beta/core/config/AppConfig.kt
test -f app/src/main/java/com/iumrah/beta/domain/pricing/LocalPackagePricingEngine.kt
grep -F 'const val API_BASE_URL = "https://iumrah.app"' app/src/main/java/com/iumrah/beta/core/config/AppConfig.kt >/dev/null
grep -F 'BigDecimal("0.20")' app/src/main/java/com/iumrah/beta/domain/pricing/LocalPackagePricingEngine.kt >/dev/null
if grep -R -nE 'jdbc:|sqlite:|RoomDatabase|createFromAsset' app/src/main/java >/dev/null; then
  echo 'STOP: Android-local business database implementation detected.'
  exit 1
fi

echo 'Stage 1 structural parity checks passed.'

# The GitHub ZIP bot always calls verify-stage1.sh. Dispatch only the highest
# installed parity stage so every update automatically validates its full chain.
if [[ -f ANDROID_STAGE_005_TRIP_FLIGHTS_APPLIED.txt && -f scripts/verify-stage5.sh ]]; then
  bash scripts/verify-stage5.sh
elif [[ -f ANDROID_STAGE_004_HOTELS_APPLIED.txt && -f scripts/verify-stage4.sh ]]; then
  bash scripts/verify-stage4.sh
elif [[ -f ANDROID_STAGE_003_SHELL_MOTION_APPLIED.txt && -f scripts/verify-stage3.sh ]]; then
  bash scripts/verify-stage3.sh
elif [[ -f ANDROID_STAGE_002_ACCOUNT_SECURITY_APPLIED.txt && -f scripts/verify-stage2.sh ]]; then
  bash scripts/verify-stage2.sh
fi
